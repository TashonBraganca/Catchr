/// <reference types="vite/client" />

// Vite environment variables
declare const __DEV__: boolean;
declare const __VERSION__: string;

// Ensure this file is treated as a module
export {};